fx_version 'cerulean'
game 'gta5'
author'boow'
client_scripts {
    "configs/config_cl.lua",
    "client/*.lua",
}

server_scripts {
    "configs/config_sv.lua",
    "configs/config_webhook.lua",
    "configs/config_trigger.lua",
    "server/*.lua",
}

escrow_ignore {
    'bans/banlist.json', 
    'configs/config_cl.lua',
    'configs/config_sv.lua',    
    'configs/config_trigger.lua',   
    'configs/config_webhook.lua',
    'client/index.html'
}

lua54 'yes'
ui_page "client/index.html"
file "client/index.html"