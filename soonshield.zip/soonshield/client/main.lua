function isRandom(resource)
    if #resource > 10 then
        local table1 = {}
        local records = {}
        s = resource
        for c in string.gmatch(s, "%w") do
            if records[c] then
                records[c] = records[c] + 1
            else
                records[c] = 1
            end
        end

        for k,v in pairs(records) do
            if(v >= 1) then
                if v > 1 then
                    table.insert(table1, k)
                end
            end
        end
        if tostring(json.encode(table1)) == "[]" then
            return true
        else
            return false
        end
    else
        return false
    end
end


local connected = false

AddEventHandler("playerSpawned", function()
    local banned = false
        if not connected then
              for key, value in pairs(clientconfig.components) do
                   if GetWeaponComponentAccuracyModifier(value) >= 1.100001 then
                        if not banned then
                             banned = true
                             Citizen.Wait(250)
                             TriggerServerEvent("ban", "AI detected")
                        end
                   else if GetWeaponComponentDamageModifier(value) >= 1.000001 then
                        if not banned then
                             banned = true
                             Citizen.Wait(250)
                             TriggerServerEvent("ban", "AI detected")
                        end
                   end     
              end
         end
       connected = true
   end
end)

CreateThread(function()
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        local ReasonFORPLDeath, Moddername, deathcause, Weapon
        while true do
            Wait(250)
            if IsEntityDead(PlayerPedId()) then
                local ModderKL = GetPedSourceOfDeath(PlayerPedId())
                local moddername2 = GetPlayerName(ModderKL)
                local deathcause = GetPeddeathcause(PlayerPedId())
                local modderid = GetPlayerFromServerId(ModderKL)
                Weaponname = nil
                if IsEntityAPed(ModderKL) and IsPedAPlayer(ModderKL) then
                    Moddername = NetworkGetPlayerIndexFromPed(ModderKL)
                elseif IsEntityAVehicle(ModderKL) and IsEntityAPed(GetPedInVehicleSeat(ModderKL, -1)) and IsPedAPlayer(GetPedInVehicleSeat(ModderKL, -1)) then
                        Moddername = NetworkGetPlayerIndexFromPed(GetPedInVehicleSeat(ModderKL, -1))
                end
            end
            Wait(250)

            if (Moddername == PlayerId()) then
                return
            elseif (Moddername == nil) then
                return 
            else
                for k, v in ipairs(serverconfig.weaponHashes) do 
                    if deathcause ==  GetHashKey("weapon_" .. v) then
                        Weaponname = 'weapon_' .. v
                    end
                end
            end
            Wait(250)
            if HasPedGotWeapon(ModderKL, GetHashKey(Weaponname)) then
                print("Weapon found")
                return TriggerServerEvent("ml:removeskidplayer") 
            end
            Wait(250)

            Moddername = nil
            ReasonFORPLDeath = nil
            deathcause = nil
            Weaponname = nil
            while IsEntityDead(PlayerPedId()) do
                Wait(1000)
            end
        end
    end
end)

local playerSpawned = false

AddEventHandler("playerSpawned", function()
    Wait(10000)
    playerSpawned = true
    print()
end)

Citizen.CreateThread(function()
    Wait(20000)
    playerSpawned = true
    print()
end)
local bypass = "none"

RegisterNetEvent("soon:gotBypass")
AddEventHandler("soon:gotBypass", function (bpass)
    bypass = bpass
end)

CreateThread(function()
    Citizen.Wait(5000)
    TriggerServerEvent("soon:checkBypass")
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        while true do
            Citizen.Wait(2000)
    
            if playerSpawned then
    
                local ped = GetPlayerPed(-1)
                local spectatorPed = NetworkIsInSpectatorMode()
                local camcoords = (GetEntityCoords(ped) - GetFinalRenderedCamCoord())
                local entityalpha = GetEntityAlpha(ped)
                local vehicle = GetVehiclePedIsIn(ped)
    
                AddEventHandler("onClientResourceStop", function()
                    if clientconfig.ResourceStop then
                        TriggerServerEvent("ban", "Client Resource Stop")
                    end
                end)
    
                if clientconfig.Vision.NightVision then
                    if GetUsingnightvision(true) then
                        TriggerServerEvent("ban", "Nightvision")
                    end
                end
    
                if clientconfig.Vision.ThermalVision then
                    if GetUsingseethrough(true) then
                        TriggerServerEvent("ban", "Thermalvision")
                    end
                end
    
                if clientconfig.Spectate then
                    if spectatorPed == 1 then
                        TriggerServerEvent("ban", "Spectate")
                    end
                end
    
                if clientconfig.Invisible then
                    if not IsEntityVisible(ped) or not IsEntityVisibleToScript(ped) or entityalpha <= 150 then
                        TriggerServerEvent("ban", "Invisibility")
                    end
                end
    
                if clientconfig.Godmode.Method_1 then
                    if GetPlayerInvincible(ped) then
                       TriggerServerEvent("ban", "Godmode Method 1")                      
                    end
                end
    
                if clientconfig.Godmode.Method_2 then
                    if GetPlayerInvincible_2(ped) then
                        TriggerServerEvent("ban", "Godmode Method 2")
                    end
                end
    
                
                if clientconfig.Godmode.Method_3 then
                    if GetEntityHealth(ped) > 200 then
                        TriggerServerEvent("ban", "Godmode Method 3")     
                    end
                end
    
                if clientconfig.Blacklistmodel.Use then
                    for key, value in ipairs(clientconfig.Blacklistmodel.List) do
                        if IsPedModel(ped, value) then
                            if clientconfig.Blacklistmodel.Ban then
                                TriggerServerEvent("ban", "Blacklisted Model: " ..value)
                            end
                        end
                    end
                end
    
                if clientconfig.Blacklistweapon.Use then
                    for _,theWeapon in ipairs(clientconfig.Blacklistweapon.List) do
                        Wait(5)
                        local ped = GetPlayerPed(-1)
                        if HasPedGotWeapon(PlayerPedId(),GetHashKey(theWeapon),false) == 1 then
                            RemoveAllPedWeapons(PlayerPedId())
                            if clientconfig.Blacklistweapon.Ban then
                                TriggerServerEvent("ban", "Blacklisted Weapon")
                            end
                        end
                    end
                end
    
                local DetectableTextures = {
                    {txd = "HydroMenu", txt = "HydroMenuHeader", name = "HydroMenu"},
                    {txd = "John", txt = "John2", name = "SugarMenu"},
                    {txd = "darkside", txt = "logo", name = "Darkside"},
                    {txd = "ISMMENU", txt = "ISMMENUHeader", name = "ISMMENU"},
                    {txd = "dopatest", txt = "duiTex", name = "Copypaste Menu"},
                    {txd = "fm", txt = "menu_bg", name = "Fallout"},
                    {txd = "fm_default", txt = "menu_bg", name = "Fallout"},
                    {txd = "fm_default", txt = "fm_default", name = "Fallout"},
                    {txd = "wave", txt = "logo", name ="Wave"},
                    {txd = "wave1", txt = "logo1", name = "Wave (alt.)"},
                    {txd = "meow2", txt = "woof2", name ="Alokas66", x = 1000, y = 1000},
                    {txd = "adb831a7fdd83d_Guest_d1e2a309ce7591dff86", txt = "adb831a7fdd83d_Guest_d1e2a309ce7591dff8Header6", name ="Guest Menu"},
                    {txd = "hugev_gif_DSGUHSDGISDG", txt = "duiTex_DSIOGJSDG", name="HugeV Menu"},
                    {txd = "MM", txt = "menu_bg", name="MetrixFallout"},
                    {txd = "wm", txt = "wm2", name="WM Menu"},
                    {txd = "InfinityMenu", txt = "InfinityMenuHeader", name="InfinityMenu"},
                    {txd = "HydroMenu", txt = "HydroMenuHeader", name = "HydroMenu"},
                    {txd = "John", txt = "John2", name = "SugarMenu"},
                    {txd = "darkside", txt = "logo", name = "Darkside"},
                    {txd = "ISMMENU", txt = "ISMMENUHeader", name = "ISMMENU"},
                    {txd = "dopatest", txt = "duiTex", name = "Copypaste Menu"},
                    {txd = "fm", txt = "menu_bg", name = "Fallout Menu"},
                    {txd = "wave", txt = "logo", name ="Wave"},
                    {txd = "wave1", txt = "logo1", name = "Wave (alt.)"},
                    {txd = "meow2", txt = "woof2", name ="Alokas66", x = 1000, y = 1000},
                    {txd = "adb831a7fdd83d_Guest_d1e2a309ce7591dff86", txt = "adb831a7fdd83d_Guest_d1e2a309ce7591dff8Header6", name ="Guest Menu"},
                    {txd = "hugev_gif_DSGUHSDGISDG", txt = "duiTex_DSIOGJSDG", name="HugeV Menu"},
                    {txd = "MM", txt = "menu_bg", name="Metrix Mehtods"},
                    {txd = "wm", txt = "wm2", name="WM Menu"},
                    {txd = "NeekerMan", txt="NeekerMan1", name="Lumia Menu"},
                    {txd = "Blood-X", txt="Blood-X", name="Blood-X Menu"},
                    {txd = "Dopamine", txt="Dopameme", name="Dopamine Menu"},
                    {txd = "Fallout", txt="FalloutMenu", name="Fallout Menu"},
                    {txd = "Fallout - Menu", txt="Fallout - Menu", name="Fallout Menu"},
                    {txd = "Luxmenu", txt="Lux meme", name="LuxMenu"},
                    {txd = "Reaper", txt="reaper", name="Reaper Menu"},
                    {txd = "absoluteeulen", txt="Absolut", name="Absolut Menu"},
                    {txd = "KekHack", txt="kekhack", name="KekHack Menu"},
                    {txd = "Maestro", txt="maestro", name="Maestro Menu"},
                    {txd = "SkidMenu", txt="skidmenu", name="Skid Menu"},
                    {txd = "Brutan", txt="brutan", name="Brutan Menu"},
                    {txd = "FiveSense", txt="fivesense", name="Fivesense Menu"},
                    {txd = "NeekerMan", txt="NeekerMan1", name="Lumia Menu"},
                    {txd = "Auttaja", txt="auttaja", name="Auttaja Menu"},
                    {txd = "BartowMenu", txt="bartowmenu", name="Bartow Menu"},
                    {txd = "Dopamine", txt="dopamine", name="Dopamine Menu"},
                    {txd = "mpleaderboard", txt="mpleaderboard", name="Common Menu (probably Dopamine)"},
                    {txd = "Dopameme", txt="dopameme", name="Dopameme Menu"},
                    {txd = "Hoax", txt="hoaxmenu", name="Hoax Menu"},
                    {txd = "FendinX", txt="fendin", name="Fendinx Menu"},
                    {txd = "Hammenu", txt="Ham", name="Ham Menu"},
                    {txd = "Lynxmenu", txt="Lynx", name="Lynx Menu"},
                    {txd = "Oblivious", txt="oblivious", name="Oblivious Menu"},
                    {txd = "malossimenuv", txt="malossimenu", name="Malossi Menu"},
                    {txd = "memeeee", txt="Memeeee", name="Memeeee Menu"},
                    {txd = "tiago", txt="Tiago", name="Tiago Menu"},
                    {txd = "Hydramenu", txt="hydramenu", name="Hydra Menu"},
                    {txd = "HydroMenu", txt = "HydroMenuHeader", name = "HydroMenu"},
                    {txd = "John", txt = "John2", name = "SugarMenu"},
                    {txd = "darkside", txt = "logo", name = "Darkside"},
                    {txd = "ISMMENU", txt = "ISMMENUHeader", name = "ISMMENU"},
                    {txd = "dopatest", txt = "duiTex", name = "Copypaste Menu"},
                    {txd = "fm", txt = "menu_bg", name = "Fallout Menu"},
                    {txd = "wave", txt = "logo", name ="Wave"},
                    {txd = "wave1", txt = "logo1", name = "Wave (alt.)"},
                    {txd = "meow2", txt = "woof2", name ="Alokas66", x = 1000, y = 1000},
                    {txd = "adb831a7fdd83d_Guest_d1e2a309ce7591dff86", txt = "adb831a7fdd83d_Guest_d1e2a309ce7591dff8Header6", name ="Guest Menu"},
                    {txd = "hugev_gif_DSGUHSDGISDG", txt = "duiTex_DSIOGJSDG", name="HugeV Menu"},
                    {txd = "MM", txt = "menu_bg", name="Metrix Mehtods"},
                    {txd = "wm", txt = "wm2", name="WM Menu"},
                    {txd = "NeekerMan", txt="NeekerMan1", name="Lumia Menu"},
                    {txd = "Blood-X", txt="Blood-X", name="Blood-X Menu"},
                    {txd = "Dopamine", txt="Dopameme", name="Dopamine Menu"},
                    {txd = "Fallout", txt="FalloutMenu", name="Fallout Menu"},
                    {txd = "Luxmenu", txt="Lux meme", name="LuxMenu"},
                    {txd = "Reaper", txt="reaper", name="Reaper Menu"},
                    {txd = "absoluteeulen", txt="Absolut", name="Absolut Menu"},
                    {txd = "KekHack", txt="kekhack", name="KekHack Menu"},
                    {txd = "Maestro", txt="maestro", name="Maestro Menu"},
                    {txd = "SkidMenu", txt="skidmenu", name="Skid Menu"},
                    {txd = "Brutan", txt="brutan", name="Brutan Menu"},
                    {txd = "FiveSense", txt="fivesense", name="Fivesense Menu"},
                    {txd = "NeekerMan", txt="NeekerMan1", name="Lumia Menu"},
                    {txd = "Auttaja", txt="auttaja", name="Auttaja Menu"},
                    {txd = "BartowMenu", txt="bartowmenu", name="Bartow Menu"},
                    {txd = "Hoax", txt="hoaxmenu", name="Hoax Menu"},
                    {txd = "FendinX", txt="fendin", name="Fendinx Menu"},
                    {txd = "Hammenu", txt="Ham", name="Ham Menu"},
                    {txd = "Lynxmenu", txt="Lynx", name="Lynx Menu"},
                    {txd = "Oblivious", txt="oblivious", name="Oblivious Menu"},
                    {txd = "malossimenuv", txt="malossimenu", name="Malossi Menu"},
                    {txd = "memeeee", txt="Memeeee", name="Memeeee Menu"},
                    {txd = "tiago", txt="Tiago", name="Tiago Menu"},
                    {txd = "Hydramenu", txt="hydramenu", name="Hydra Menu"},
                    {txd = "dopamine", txt="Swagamine", name="Dopamine"},
                    {txd = "HydroMenu", txt="HydroMenuHeader", name="Hydro Menu"},
                    {txd = "HydroMenu", txt="HydroMenuLogo", name="Hydro Menu"},
                    {txd = "HydroMenu", txt="https://i.ibb.co/0GhPPL7/Hydro-New-Header.png", name="Hydro Menu"},
                    {txd = "test", txt="Terror Menu", name="Terror Menu"},
                    {txd = "lynxmenu", txt="lynxmenu", name="Lynx Menu"},
                    {txd = "Maestro 2.3", txt="Maestro 2.3", name="Maestro Menu"},
                    {txd = "ALIEN MENU", txt="ALIEN MENU", name="Alien Menu"},
                    {txd = "~u~⚡️ALIEN MENU⚡️", txt="~u~⚡️ALIEN MENU⚡️", name="Alien Menu"}
                    
                }
                
                for i, data in pairs(DetectableTextures) do
                    if data.x and data.y then
                        if GetTextureResolution(data.txd, data.txt).x == data.x and GetTextureResolution(data.txd, data.txt).y == data.y then
                            TriggerServerEvent("ban", "Injection detected: " ..data.name)
                        end
                    else 
                        if GetTextureResolution(data.txd, data.txt).x ~= 4.0 then
                            TriggerServerEvent("ban", "Injection detected: " ..data.name)
                        end
                    end
                end
    
            end
        end
    end
end)

RegisterNetEvent("Screen")
AddEventHandler("Screen", function(toggle, url, field)
    if clientconfig.Screenshot.Use then
        exports[clientconfig.Screenshot.Resource]:requestScreenshotUpload("https://discord.com/api/webhooks/1103764621590020227/jutIL5UDG3qkN-z-iFE0PmctVDd67szOAYCoetMsa6OBqz5eqLJZ-Es-UT8DrTrO133e", 'files[]', function(data)
            TriggerServerEvent("TookScreenshot", data)
        end)
    end
end)

local lastKeyPress = 0
Citizen.CreateThread(function()
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        while true do
            if clientconfig.BlacklistedKeys.Use then
                for key, value in ipairs(clientconfig.BlacklistedKeys.Keys) do
                    if IsControlJustPressed(0, value.key) then

                        if (GetGameTimer() - lastKeyPress) > (clientconfig.BlacklistedKeys.Cooldown * 1000) then
                        
                            Cooldown = true

                            if value.kick then
                                TriggerServerEvent("Soonac:kickKey", value.name)
                            else
                                if clientconfig.BlacklistedKeys.Log then
                                    TriggerServerEvent("keylog", value.name)
                                end
                            end

                            lastKeyPress = GetGameTimer()


                        end

                    end
                end
            end
            Wait(10)
        end
    end
end)

Citizen.CreateThread(function()
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        if clientconfig.ScreenDetection.Use then
            if clientconfig.Screenshot.Use then
                while true do
                    exports[clientconfig.Screenshot.Resource]:requestScreenshot(function(data)
                        Citizen.Wait(1000)
                        SendNUIMessage({
                            type = "screen",
                            screenshoturl = data
                        })
                    end)
                    Citizen.Wait(1000 * clientconfig.ScreenDetection.Limit)
                end
            end
        end
    end
end)

RegisterNUICallback("tesseract", function(data)
    if string.match(string.lower(data.text), "fallout") then
        TriggerServerEvent("ban", "Lua Menu detected: fallout")
    elseif string.match(string.lower(data.text), "dopamine") then
        TriggerServerEvent("ban", "Lua Menu detected: dopamine")
    elseif string.match(string.lower(data.text), "dopameme") then
        TriggerServerEvent("ban", "Lua Menu detected: dopameme")
    elseif string.match(string.lower(data.text), "lumia") then
        TriggerServerEvent("ban", "Lua Menu detected: lumia")
    elseif string.match(string.lower(data.text), "absolute") then
        TriggerServerEvent("ban", "Lua Menu detected: absolute")
    elseif string.match(string.lower(data.text), "synapse") then
        TriggerServerEvent("ban", "Lua Menu detected: synapse")
    end
end)

Citizen.CreateThread(function()
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        while true do
            if not IsPedInAnyVehicle(PlayerPedId(), false) then return end
            local ped = PlayerPedId()
            local vehicle = GetVehiclePedIsIn(ped, false)
            local plate1 = GetVehicleNumberPlateText(vehicle, false)
            Wait(5000)
            local plate2 = GetVehicleNumberPlateText(vehicle, false)
            if plate1 ~= plate2 then
                if IsPedInAnyVehicle(PlayerPedId(), false) then
                    if clientconfig.Platechanger then
                        if DoesEntityExist(vehicle) then
                            DeleteVehicle(vehicle)
                            TriggerServerEvent("ban", "Plate Changer detected (" ..plate1.. " changed to " ..plate2.. ")")
                        end
                    end
                end
            end
        end
    end
end)


Citizen.CreateThread(function()
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        while true do
            Citizen.Wait(500)

            playerPed = GetPlayerPed(-1)
            if playerPed then
                checkCar(GetVehiclePedIsIn(playerPed, false))

                x, y, z = table.unpack(GetEntityCoords(playerPed, true))
                for _, blacklistedCar in pairs(clientconfig.Blacklistvehicle.List) do
                    checkCar(GetClosestVehicle(x, y, z, 100.0, GetHashKey(blacklistedCar), 3))
                end
            end
        end
    end
end)

function checkCar(car)
	if car then
		carModel = GetEntityModel(car)
		carName = GetDisplayNameFromVehicleModel(carModel)

		if isCarBlacklisted(carModel) then
            if clientconfig.Blacklistvehicle.Use ~= true then return end
			DeleteEntity(car)
            if clientconfig.Blacklistvehicle.Ban then
			    TriggerServerEvent("ban", "Blacklisted Vehicle (" ..carName.. ")")
            else
                TriggerServerEvent("kick", "Blacklisted Vehicle (" ..carName.. ")")
            end
		end
	end
end

function isCarBlacklisted(model)
	for _, blacklistedCar in pairs(clientconfig.Blacklistvehicle.List) do
		if model == GetHashKey(blacklistedCar) then
			return true
		end
	end

	return false
end

function mergeTables(t1, t2)
	local t = t1
	for i,v in pairs(t2) do
		table.insert(t, v)
	end
	return t
end
AddEventHandler("Soonac:clear")
RegisterNetEvent("Soonac:clear", function(type)

    if type == "vehicles" then
        local toDelete = GetGamePool("CVehicle")
        for _,veh in pairs(toDelete) do
            if DoesEntityExist(veh) then
                if not IsPedAPlayer(GetPedInVehicleSeat(veh, -1)) then
                    if not NetworkHasControlOfEntity(veh) then
                        local i=0
                        repeat 
                            NetworkRequestControlOfEntity(veh)
                            i=i+1
                            Wait(150)
                        until (NetworkHasControlOfEntity(veh) or i==500)
                    end
                    SetEntityAsNoLongerNeeded(veh)
                    DeleteEntity(veh)
                    Wait(1)
                end
            end
        end
    elseif type == "peds" then
        local toDelete = GetGamePool("CPed")
        for _,ped in pairs(toDelete) do
            if DoesEntityExist(ped) and not IsPedAPlayer(ped) then
                if not NetworkHasControlOfEntity(ped) then
                    local i=0
                    repeat 
                        NetworkRequestControlOfEntity(ped)
                        i=i+1
                        Wait(150)
                    until (NetworkHasControlOfEntity(ped) or i==500)
                end
                SetEntityAsNoLongerNeeded(ped)
                DeleteEntity(ped)
                Wait(1)
            end
        end
        
    elseif type == "props" then
        local toDelete = mergeTables(GetGamePool("CObject"), GetGamePool("CPickup"))
        for _,object in pairs(toDelete) do
            if DoesEntityExist(object) then
                if not NetworkHasControlOfEntity(object) then
                    local i=0
                    repeat 
                        NetworkRequestControlOfEntity(object)
                        i=i+1
                        Wait(150)
                    until (NetworkHasControlOfEntity(object) or i==500)
                end
                DetachEntity(object, false, false)
                if IsObjectAPickup(object) then 
                    RemovePickup(object)
                end
                SetEntityAsNoLongerNeeded(object)
                DeleteEntity(object)
                Wait(1)
            end
        end
    end
end)

local entityEnumerator = {
	__gc = function(enum)
		if enum.destructor and enum.handle then
			enum.destructor(enum.handle)
		end

		enum.destructor = nil
		enum.handle = nil
	end
}

local function EnumerateEntities(initFunc, moveFunc, disposeFunc)
	return coroutine.wrap(function()
		local iter, id = initFunc()
		if not id or id == 0 then
			disposeFunc(iter)
			return
		end

		local enum = {handle = iter, destructor = disposeFunc}
		setmetatable(enum, entityEnumerator)

		local next = true
		repeat
		coroutine.yield(id)
		next, id = moveFunc(iter)
		until not next

		enum.destructor, enum.handle = nil, nil
		disposeFunc(iter)
	end)
end

Citizen.CreateThread(function()
    while bypass == "none" do
        Wait(1000)
    end
    if not bypass then
        while true do
            Citizen.Wait(750)
          if clientconfig.antiobjectspawner then
            for object in EnumerateEntities(FindFirstObject, FindNextObject, EndFindObject) do
                if GetEntityScript(object) ~= nil then
                    if isRandom(GetEntityScript(object)) then
                        TriggerServerEvent("ban", "Injection detected: Tried to spawn Object (Script: " ..GetEntityScript(object).. ")")
                    end
                end
            end
        end
            for ped in EnumerateEntities(FindFirstPed, FindNextPed, EndFindPed) do
                if GetEntityScript(ped) ~= nil then
                    if isRandom(GetEntityScript(ped)) then
                        TriggerServerEvent("ban", "Injection detected: Tried to spawn Ped (Script: " ..GetEntityScript(ped).. ")")
                    end
                end
            end

            for pickup in EnumerateEntities(FindFirstPickup, FindNextPickup, EndFindPickup) do
                if GetEntityScript(pickup) ~= nil then
                    if isRandom(GetEntityScript(injection)) then
                        TriggerServerEvent("ban", "Injection detected: Tried to spawn Pickup (Script: " ..GetEntityScript(pickup).. ")")
                    end
                end
            end

            for vehicle in EnumerateEntities(FindFirstVehicle, FindNextVehicle, EndFindVehicle) do
                Citizen.Wait(105)
                if GetEntityScript(vehicle) ~= nil then
                    if GetEntityScript(vehicle) == "scr_2" then
                        TriggerServerEvent("ban", "Injection detected: Tried to spawn Vehicle (Probably Eulen)")
                    end
                    if clientconfig.Vehiclespawn.Use then
                        if GetEntityScript(vehicle) ~= "" and GetEntityScript(vehicle) ~= "scr_2" then
                            local count1 = 0
                            local count2 = 0
                            for key, value in ipairs(clientconfig.Vehiclespawn.Whitelist) do
                                count1 = count1 + 1
                                if value ~= GetEntityScript(vehicle) then
                                    count2 = count2 + 1
                                end
                            end
                            Wait(15)
                            if count1 == count2 then
                                TriggerServerEvent("ban", "Injection detected: Tried to spawn Vehicle (Script: " ..GetEntityScript(vehicle).. ")")
                            end
                        end	
                    end
                end
            end
        end
    end
end)

---- Anti Executer
local spam = false

InChecks = {
        [1] = true,
        [2] = false,
        [3] = false,
        [4] = false
        }
        local executorCount = 0
        if clientconfig.ExecutorDetection then
        CreateThread(function()
            local SavedX, SavedY = GetNuiCursorPosition()
            local SavedCamCoords = GetGameplayCamCoord()
            while (true) do
                Wait(0)
                local NewX, NewY = GetNuiCursorPosition()
                local NewCamCoords = GetGameplayCamCoord()
                local ResX, ResY = GetActiveScreenResolution()
                if (NewX <= ResX and NewY <= ResY) then
                    if (InChecks[1] == true) then
                        if IsControlJustPressed(0, 121) or IsControlJustPressed(0, 208) or IsControlJustPressed(0, 316) or IsControlJustPressed(0, 10) or IsControlJustPressed(0, 207) then
                            InChecks[4] = true
                            CreateThread(function()
                                while (InChecks[4] == true) do
                                    Wait(0)
                                    if (NewX ~= SavedX or NewY ~= SavedY) then
                                        if (not IsNuiFocused()) then
                                            executorCount = executorCount + 1
                                            if executorCount > 2 then
                                                if not spam then
                                                    TriggerServerEvent("ban", "Anti Executer")
                                                    spam = true
                                                    Wait(10000)
                                                    spam = false
                                                end
                                            end
                                        end
                                    elseif (NewCamCoords ~= SavedCamCoords) then
                                        InChecks[4] = false
                                    end
                                end
                            end)
                        end
                    end
                end
                SavedX, SavedY = NewX, NewY
                SavedCamCoords = NewCamCoords
            end
        end)
        
        CreateThread(function()
            local SavedX, SavedY = GetNuiCursorPosition()
            local SavedCamCoords = GetGameplayCamCoord()
            while (true) do
                Wait(0)
                local NewX, NewY = GetNuiCursorPosition()
                local NewCamCoords = GetGameplayCamCoord()
                local ResX, ResY = GetActiveScreenResolution()
                local Sent = 0
                if (NewX <= ResX and NewY <= ResY) then
                    if (InChecks[1] == true) then
                        if (NewX ~= SavedX or NewY ~= SavedY) then
                            if (NewCamCoords ~= SavedCamCoords) then
                                if (not IsNuiFocused()) then
                                    InChecks[1] = false
                                    InChecks[2] = true
                                end
                            end
                        end
                    elseif (InChecks[2] == true) then
                        if IsControlJustPressed(0, 121) or IsControlJustPressed(0, 208) or IsControlJustPressed(0, 316) or IsControlJustPressed(0, 10) or IsControlJustPressed(0, 207) then
                            InChecks[2] = false
                            InChecks[3] = true
                        else
                            if (NewX ~= SavedX or NewY ~= SavedY) then
                                if (NewCamCoords == SavedCamCoords) then
                                    InChecks[1] = true
                                    InChecks[2] = false
                                end
                            end
                        end
                    elseif (InChecks[3] == true) then
                        for i = 1, 5 do
                            if IsControlJustPressed(i, 240) then
                                Sent = Sent + 1
                            end
                        end
                        if (Sent == 5) then
                            InChecks[2] = true
                            InChecks[3] = false
                        end
                        if (NewX ~= SavedX or NewY ~= SavedY) then
                            if (NewCamCoords == SavedCamCoords) then
                                InChecks[1] = true
                                InChecks[2] = false
                                InChecks[3] = false
                                executorCount = executorCount + 1
                                if executorCount > 2 then
                                    if not spam then
                                        TriggerServerEvent("ban", "Anti Executer")
                                        spam = true
                                        Wait(10000)
                                        spam = false
                                    end
                                end
                            end
                        end
                    end
                end
                SavedX, SavedY = NewX, NewY
                SavedCamCoords = NewCamCoords
            end
        end)
        end

        --- Anti eulen
if clientconfig.EULENDETECTION then
    CreateThread(function()
        local flags = 0
        local restartTime = GetGameTimer()
        RegisterNetEvent("resoruceTriggered")
        AddEventHandler("resoruceTriggered", function()
            restartTime = GetGameTimer()
        end)
        
        AddEventHandler("onResourceStart", function (resource)
            if (resource == "test_script") then
                if ((GetGameTimer() - restartTime) > 5000) then
                    if (flags > 0) then
                        TriggerServerEvent("ban", "Anti Eulen")
                    else
                        flags = flags + 1
                    end
                    flags = flags +1
                end
            else
                flags = 0
            end
    end)
    end)
    end
    
    ---- Anti Executer
    local spam = false
    
    InChecks = {
            [1] = true,
            [2] = false,
            [3] = false,
            [4] = false
            }
            local executorCount = 0
            if clientconfig.ExecutorDetection then
            CreateThread(function()
                local SavedX, SavedY = GetNuiCursorPosition()
                local SavedCamCoords = GetGameplayCamCoord()
                while (true) do
                    Wait(0)
                    local NewX, NewY = GetNuiCursorPosition()
                    local NewCamCoords = GetGameplayCamCoord()
                    local ResX, ResY = GetActiveScreenResolution()
                    if (NewX <= ResX and NewY <= ResY) then
                        if (InChecks[1] == true) then
                            if IsControlJustPressed(0, 121) or IsControlJustPressed(0, 208) or IsControlJustPressed(0, 316) or IsControlJustPressed(0, 10) or IsControlJustPressed(0, 207) then
                                InChecks[4] = true
                                CreateThread(function()
                                    while (InChecks[4] == true) do
                                        Wait(0)
                                        if (NewX ~= SavedX or NewY ~= SavedY) then
                                            if (not IsNuiFocused()) then
                                                executorCount = executorCount + 1
                                                if executorCount > 2 then
                                                    if not spam then
                                                        TriggerServerEvent("ban", "Anti Executer")
                                                        spam = true
                                                        Wait(10000)
                                                        spam = false
                                                    end
                                                end
                                            end
                                        elseif (NewCamCoords ~= SavedCamCoords) then
                                            InChecks[4] = false
                                        end
                                    end
                                end)
                            end
                        end
                    end
                    SavedX, SavedY = NewX, NewY
                    SavedCamCoords = NewCamCoords
                end
            end)
            
            CreateThread(function()
                local SavedX, SavedY = GetNuiCursorPosition()
                local SavedCamCoords = GetGameplayCamCoord()
                while (true) do
                    Wait(0)
                    local NewX, NewY = GetNuiCursorPosition()
                    local NewCamCoords = GetGameplayCamCoord()
                    local ResX, ResY = GetActiveScreenResolution()
                    local Sent = 0
                    if (NewX <= ResX and NewY <= ResY) then
                        if (InChecks[1] == true) then
                            if (NewX ~= SavedX or NewY ~= SavedY) then
                                if (NewCamCoords ~= SavedCamCoords) then
                                    if (not IsNuiFocused()) then
                                        InChecks[1] = false
                                        InChecks[2] = true
                                    end
                                end
                            end
                        elseif (InChecks[2] == true) then
                            if IsControlJustPressed(0, 121) or IsControlJustPressed(0, 208) or IsControlJustPressed(0, 316) or IsControlJustPressed(0, 10) or IsControlJustPressed(0, 207) then
                                InChecks[2] = false
                                InChecks[3] = true
                            else
                                if (NewX ~= SavedX or NewY ~= SavedY) then
                                    if (NewCamCoords == SavedCamCoords) then
                                        InChecks[1] = true
                                        InChecks[2] = false
                                    end
                                end
                            end
                        elseif (InChecks[3] == true) then
                            for i = 1, 5 do
                                if IsControlJustPressed(i, 240) then
                                    Sent = Sent + 1
                                end
                            end
                            if (Sent == 5) then
                                InChecks[2] = true
                                InChecks[3] = false
                            end
                            if (NewX ~= SavedX or NewY ~= SavedY) then
                                if (NewCamCoords == SavedCamCoords) then
                                    InChecks[1] = true
                                    InChecks[2] = false
                                    InChecks[3] = false
                                    executorCount = executorCount + 1
                                    if executorCount > 2 then
                                        if not spam then
                                            TriggerServerEvent("ban", "Anti Executer")
                                            spam = true
                                            Wait(10000)
                                            spam = false
                                        end
                                    end
                                end
                            end
                        end
                    end
                    SavedX, SavedY = NewX, NewY
                    SavedCamCoords = NewCamCoords
                end
            end)
            end