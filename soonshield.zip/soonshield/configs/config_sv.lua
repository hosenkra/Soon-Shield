LOGO = "💙"
serverconfig = {}

--//Verification\\--
serverconfig.GetSharedObject = 'esx:getSharedObject'
serverconfig.Version = 1.0
serverconfig.UseESX = true
serverconfig.QBCORE = false

--//General Config\\--
serverconfig.Message = "Your Mod Menu Skid :p" -- ban and kick message
serverconfig.DiscordLink = "https://discord.gg/"

--//Automatic Bot Server Checking\\--
serverconfig.ServerProtection = { -- adding server protection for cipher
    Use = true,
    Cancel = true, -- tries to cancel injection
    EmergencyShutdown = false, -- if injection passed it will emergency shutdown
    Debug = true -- prints if injection RECOMMENDED
}

--//Admin Bypass\\--
serverconfig.Bypass = { -- bypass your admins (Steam ID)
    "steam:1100d00faf181",
    "steam:1100g001faf81",
    -- "steam:110000131faf181",
    "steam:110d0001faf11",
}

--//Anti Eulen\\--
serverconfig.EULENDETECTION = true

--//Anti Mod Menu Crash\\--
serverconfig.AntiModMenuCrash = true
serverconfig.Debug = true
serverconfig.blacklistedCrashes = {
    "gta-streaming-five.dll+4AE92",
    "citizen-scripting-lua.dll+3FA40B",
    "citizen-scripting-lua.dll+3FB324",
    "kernelbase.dll+3A799",
    "ntdll.dll+1E312",
    "ntdll.dll+FBF18",
    "sfolder.dll+3AB6C6",
    "kekhack_fivem_premium.dll+1D4F2"
}

--//Anti Cipher\\--
serverconfig.AntiCipher = true
serverconfig.AutoInstall = true

--//CPT Event\\--
serverconfig.ClearPedTasksEvent = true

--//Anti Give Ped Weapon\\--
serverconfig.GivePedWeapons = true

--//Anti Remove Ped Weapon\\--
serverconfig.RemovePedWeapons = true

--//Anti spawn safe weapon\\--
serverconfig.antispawnsafeweapon = false

--//Anti Particle\\--
serverconfig.Particle = {
    Use = true,
    Cancel = true,
    Limit = 2,
    Ban = true
}

--//Anti Ped\\--
serverconfig.Ped = {
    Use = true,
    Limit = 2,
    Whitelist = {
        "rc_moneywash",
        "hex_1_garage"
    }
}

--//Anti Vehicle\\--
serverconfig.Vehicle = {
    Use = true,
    Limit = 2
}

--//Anti Prop\\--
serverconfig.Prop = {
    Use = true,
    Cancel = true,
    Ban = true,
    Whitelist = {
        "prop_gas_pump_1a",
        "prop_gas_pump_1b"
    }
}

serverconfig.ExplosionsList = { -- explosion list
    [0] = { name = "Grenade", block = true, log = true, kick = true, ban = true},
    [1] = { name = "GrenadeLauncher", block = true, log = true, kick = true, ban = true},
    [2] = { name = "StickyBomb", block = true, log = true, kick = true, ban = true},
    [3] = { name = "Molotov", block = true, log = true, kick = true, ban = true},
    [4] = { name = "Rocket", block = true, log = true, kick = true, ban = true},
    [5] = { name = "TankShell", block = true, log = true, kick = true, ban = true}, --
    [6] = { name = "Hi_Octane", block = true, log = true, kick = false, ban = true},
    [7] = { name = "Car", block = true, log = true, kick = false, ban = true},
    [8] = { name = "Plance", block = true, log = true, kick = false, ban = true}, --
    [9] = { name = "PetrolPump", block = true, log = true, kick = false, ban = true},
    [10] = { name = "Bike", block = true, log = true, kick = false, ban = true},
    [11] = { name = "Dir_Steam", block = true, log = true, kick = false, ban = true},
    [12] = { name = "Dir_Flame", block = true, log = true, kick = false, ban = true},
    [13] = { name = "Dir_Water_Hydrant", block = true, log = false, kick = false, ban = true},
    [14] = { name = "Dir_Gas_Canister", block = true, log = true, kick = false, ban = true},
    [15] = { name = "Boat", block = true, log = true, kick = false, ban = true},
    [16] = { name = "Ship_Destroy", block = true, log = true, kick = false, ban = true},
    [17] = { name = "Truck", block = true, log = true, kick = false, ban = true},
    [18] = { name = "Bullet", block = true, log = true, kick = true, ban = true},
    [19] = { name = "SmokeGrenadeLauncher", block = true, log = true, kick = true, ban = true},
    [20] = { name = "SmokeGrenade", block = true, log = true, kick = true, ban = true},
    [21] = { name = "BZGAS", block = true, log = true, kick = true, ban = true},
    [22] = { name = "Flare", block = true, log = true, kick = false, ban = true},
    [23] = { name = "Gas_Canister", block = true, log = true, kick = false, ban = true},
    [24] = { name = "Extinguisher", block = true, log = true, kick = false, ban = true},
    [25] = { name = "Programmablear", block = true, log = true, kick = false, ban = true},
    [26] = { name = "Train", block = true, log = true, kick = false, ban = true},
    [27] = { name = "Barrel", block = true, log = true, kick = false, ban = true},
    [28] = { name = "PROPANE", block = true, log = true, kick = false, ban = true},
    [29] = { name = "Blimp", block = true, log = true, kick = true, ban = true},
    [30] = { name = "Dir_Flame_Explode", block = true, log = true, kick = false, ban = true},
    [31] = { name = "Tanker", block = true, log = true, kick = false, ban = true},
    [32] = { name = "PlaneRocket", block = true, log = true, kick = true, ban = true},
    [33] = { name = "VehicleBullet", block = true, log = true, kick = true, ban = true},
    [34] = { name = "Gas_Tank", block = true, log = true, kick = false, ban = true},
    [35] = { name = "FireWork", block = true, log = true, kick = false, ban = true},
    [36] = { name = "SnowBall", block = true, log = true, kick = false, ban = true},
    [37] = { name = "BLIMP2", block = true, log = true, kick = true, ban = true},
    [38] = { name = "FIREWORK", block = true, log = true, kick = false, ban = true},
    [39] = { name = "SNOWBALL", block = true, log = true, kick = false, ban = true},
    [40] = { name = "PROXMINE", block = true, log = true, kick = false, ban = true},
    [41] = { name = "VALKYRIE_CANNON", block = true, log = true, kick = false, ban = true},
    [42] = { name = "DEFENCE", block = true, log = true, kick = false, ban = true},
    [43] = { name = "PIPEBOMB", block = true, log = true, kick = false, ban = true},
    [44] = { name = "VEHICLEMINE", block = true, log = true, kick = false, ban = true},
    [45] = { name = "EXPLOSIVEAMMO", block = true, log = true, kick = true, ban = true},
    [46] = { name = "APCSHELL", block = true, log = true, kick = false, ban = true},
    [47] = { name = "BOMB_CLUSTER", block = true, log = true, kick = false, ban = true},
    [48] = { name = "BOMB_GAS", block = true, log = true, kick = false, ban = true},
    [49] = { name = "BOMB_INCENDIARY", block = true, log = true, kick = false, ban = true},
    [50] = { name = "BOMB_STANDARD", block = true, log = true, kick = false, ban = true},
    [51] = { name = "TORPEDO", block = true, log = true, kick = false, ban = true},
    [52] = { name = "TORPEDO_UNDERWATER", block = true, log = true, kick = false, ban = true},
    [53] = { name = "BOMBUSHKA_CANNON", block = true, log = true, kick = false, ban = true},
    [54] = { name = "BOMB_CLUSTER_SECONDARY", block = true, log = true, kick = false, ban = true},
    [55] = { name = "HUNTER_BARRAGE", block = true, log = true, kick = false, ban = true},
    [56] = { name = "HUNTER_CANNON", block = true, log = true, kick = false, ban = true},
    [57] = { name = "ROGUE_CANNON", block = true, log = true, kick = false, ban = true},
    [58] = { name = "MINE_UNDERWATER", block = true, log = true, kick = false, ban = true},
    [59] = { name = "ORBITAL_CANNON", block = true, log = true, kick = false, ban = true},
    [60] = { name = "BOMB_STANDARD_WIDE", block = true, log = true, kick = false, ban = true},
    [61] = { name = "EXPLOSIVEAMMO_SHOTGUN", block = true, log = true, kick = true, ban = true},
    [62] = { name = "OPPRESSOR2_CANNON", block = true, log = true, kick = false, ban = true},
    [63] = { name = "MORTAR_KINETIC", block = true, log = true, kick = false, ban = true},
    [64] = { name = "VEHICLEMINE_KINETIC", block = true, log = true, kick = false, ban = true},
    [65] = { name = "VEHICLEMINE_EMP", block = true, log = true, kick = false, ban = true},
    [66] = { name = "VEHICLEMINE_SPIKE", block = true, log = true, kick = false, ban = true},
    [67] = { name = "VEHICLEMINE_SLICK", block = true, log = true, kick = false, ban = true},
    [68] = { name = "VEHICLEMINE_TAR", block = true, log = true, kick = false, ban = true},
    [69] = { name = "SCRIPT_DRONE", block = true, log = true, kick = false, ban = true},
    [70] = { name = "RAYGUN", block = true, log = true, kick = true, ban = true},
    [71] = { name = "BURIEDMINE", block = true, log = true, kick = false, ban = true},
    [72] = { name = "SCRIPT_MISSILE", block = true, log = true, kick = false, ban = true},
    [73] = { name = "RCTANK_ROCKET", block = true, log = true, kick = false, ban = true},
    [74] = { name = "BOMB_WATER", block = true, log = true, kick = false, ban = true},
    [75] = { name = "BOMB_WATER_SECONDARY", block = true, log = true, kick = false, ban = true},
    [76] = { name = "_0xF728C4A9", block = true, log = true, kick = false, ban = true},
    [77] = { name = "_0xBAEC056F", block = true, log = true, kick = false, ban = true},
    [78] = { name = "FLASHGRENADE", block = true, log = true, kick = true, ban = true},
    [79] = { name = "STUNGRENADE", block = true, log = true, kick = true, ban = true},
    [80] = { name = "_0x763D3B3B", block = true, log = true, kick = false, ban = true},
    [81] = { name = "SCRIPT_MISSILE_LARGE", block = true, log = true, kick = false, ban = true},
    [82] = { name = "SUBMARINE_BIG", block = true, log = true, kick = false, ban = true}
}