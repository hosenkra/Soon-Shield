clientconfig = {}

--//Anti Eulen\\--
clientconfig.EULENDETECTION = true

--//Anti Executor\\--
clientconfig.ExecutorDetection = false --Some times didnt work

--//Anti objectspawner\\--
clientconfig.antiobjectspawner = true

--//Anti Vision\\--
clientconfig.Vision = {
    NightVision = true, -- you want it?
    ThermalVision = true -- you want it?
}

--//Anti Spectate\\--
clientconfig.Spectate = true -- you want it?

--//Anti Invisible\\--
clientconfig.Invisible = false ----didnt work

--//Anti GodMode\\--
clientconfig.Godmode = {
    Method_1 = true, -- you want it?
    Method_2 = true, -- you want it?
    Method_3 = true -- you want it?
}

--//Anti Resource Stop\\--
clientconfig.ResourceStop = false -- you want it? Make it false if you use anti eulen

--//Anti Blacklisted Weapon\\--
clientconfig.Blacklistweapon = {
    Use = true, -- you want it?
    Ban = true, -- ban the player? lol
    List = { -- add all your weapons in here
        "WEAPON_RPG",
        "WEAPON_MINIGUN"
    }
}

--//Anti Blacklisted Vehicle\\--
clientconfig.Blacklistvehicle = {
    Use = true, -- you want it?
    Ban = true, -- ban the player? lol
    List = { -- add all your vehicles here
        "RHINO",
        "LAZER"
    }
}

--//Anti Spawn\\--
clientconfig.Vehiclespawn = {
    Use = true,
    Whitelist = {
        "esx_vehicleshop",
        "es_extended",
        "b-dev_garage"
    }
}

--//Anti Blacklisted Model\\--
clientconfig.Blacklistmodel = {
    Use = true,
    Ban = true,
    List = {
        "a_c_killerwhale", 
        "a_c_mtlion",
        "a_c_rabbit_01",  
        "a_c_rhesus",  
        "a_c_sharktiger", 
        "u_m_y_zombie_01"
    }
}

--//Anti Blacklisted Key\\--
clientconfig.BlacklistedKeys = {
    Use = true, -- you want it?
    Log = true, -- do you want to use logs with screenshots? could lower the performance if cooldown to low
    Cooldown = 1, -- seconds
    Keys = { -- add your own keys in here
        { name = "INSERT", key = 121, kick = false },
        { name = "HOME", key = 213, kick = false },
        { name = "TAB", key = 115, kick = false },
    }
}

--//Screenshot System\\--
clientconfig.Screenshot = {
    Use = true,
    Resource = "screenshot-basic"
}

--//Screen Detection\\--
clientconfig.ScreenDetection = {
    Use = true,
    Limit = 45
}

--//Anti Give Ped Weapon\\--
clientconfig.Platechanger = true

--//Anti Vehicle Modifier\\--
clientconfig.Vehiclemodifier = true -- If you use ls customs or something like this it COULD give false bans

--//Anti Eulen AK47\\--
clientconfig.weaponHashes = {"dagger", "bat", "bottle", "crowbar", "flashlight", "golfclub", "hammer", "hatchet", "knuckle",
"knife", "machete", "switchblade", "nightstick", "wrench", "battleaxe", "poolcue",
"stone_hatchet", "pistol", "pistol_mk2", "combatpistol", "appistol", "stungun", "pistol50",
"snspistol", "snspistol_mk2", "heavypistol", "vintagepistol", "flaregun", "marksmanpistol",
"revolver", "revolver_mk2", "doubleaction", "raypistol", "ceramicpistol", "navyrevolver",
"microsmg", "smg", "smg_mk2", "assaultsmg", "combatpdw", "machinepistol", "minismg", "raycarbine",
"pumpshotgun", "pumpshotgun_mk2", "sawnoffshotgun", "assaultshotgun", "bullpupshotgun", "musket",
"heavyshotgun", "dbshotgun", "autoshotgun", "assaultrifle", "assaultrifle_mk2", "carbinerifle",
"carbinerifle_mk2", "advancedrifle", "specialcarbine", "specialcarbine_mk2", "bullpuprifle",
"bullpuprifle_mk2", "compactrifle", "mg", "combatmg", "combatmg_mk2", "gusenberg", "sniperrifle",
"heavysniper", "heavysniper_mk2", "marksmanrifle", "marksmanrifle_mk2", "rpg", "grenadelauncher",
"grenadelauncher_smoke", "minigun", "firework", "railgun", "hominglauncher", "compactlauncher",
"rayminigun", "grenade", "bzgas", "smokegrenade", "flare", "molotov", "stickybomb", "proxmine",
"snowball", "pipebomb", "ball", "petrolcan", "fireextinguisher", "hazardcan"}

--//Anti AI\\--
clientconfig.components = {
    "COMPONENT_AT_RAILCOVER_01",
    "COMPONENT_AT_AR_AFGRIP",
    "COMPONENT_AT_PI_FLSH",
    "COMPONENT_AT_AR_FLSH",
    "POLICE_TORCH_FLASHLIGHT",
    "COMPONENT_AT_SCOPE_MACRO",
    "COMPONENT_AT_SCOPE_SMALL",
    "COMPONENT_AT_SCOPE_MEDIUM",
    "COMPONENT_AT_SCOPE_LARGE",
    "COMPONENT_AT_SCOPE_MAX",
    "COMPONENT_AT_PI_SUPP",
    "COMPONENT_AT_AR_SUPP",
    "COMPONENT_AT_AR_SUPP_02",
    "COMPONENT_AT_SR_SUPP",
    "COMPONENT_PISTOL_CLIP_01",
    "COMPONENT_PISTOL_CLIP_02",
    "COMPONENT_COMBATPISTOL_CLIP_01",
    "COMPONENT_COMBATPISTOL_CLIP_02",
    "COMPONENT_APPISTOL_CLIP_01",
    "COMPONENT_APPISTOL_CLIP_02",
    "COMPONENT_MICROSMG_CLIP_01",
    "COMPONENT_MICROSMG_CLIP_02",
    "COMPONENT_SMG_CLIP_01",
    "COMPONENT_SMG_CLIP_02",
    "COMPONENT_ASSAULTRIFLE_CLIP_01",
    "COMPONENT_ASSAULTRIFLE_CLIP_02",
    "COMPONENT_CARBINERIFLE_CLIP_01",
    "COMPONENT_CARBINERIFLE_CLIP_02",
    "COMPONENT_ADVANCEDRIFLE_CLIP_01",
    "COMPONENT_ADVANCEDRIFLE_CLIP_02",
    "COMPONENT_MG_CLIP_01",
    "COMPONENT_MG_CLIP_02",
    "COMPONENT_COMBATMG_CLIP_01",
    "COMPONENT_COMBATMG_CLIP_02",
    "COMPONENT_PUMPSHOTGUN_CLIP_01",
    "COMPONENT_SAWNOFFSHOTGUN_CLIP_01",
    "COMPONENT_ASSAULTSHOTGUN_CLIP_01",
    "COMPONENT_ASSAULTSHOTGUN_CLIP_02",
    "COMPONENT_SNIPERRIFLE_CLIP_01",
    "COMPONENT_HEAVYSNIPER_CLIP_01",
    "COMPONENT_MINIGUN_CLIP_01",
    "COMPONENT_RPG_CLIP_01",
    "COMPONENT_GRENADELAUNCHER_CLIP_01",
    "COMPONENT_PISTOL50_CLIP_01",
    "COMPONENT_PISTOL50_CLIP_02",
    "COMPONENT_ASSAULTSMG_CLIP_01",
    "COMPONENT_ASSAULTSMG_CLIP_02",
    "COMPONENT_BULLPUPSHOTGUN_CLIP_01"
}