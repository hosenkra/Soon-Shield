--//Discord Logs\\--
webhookconfig = {
    webhooks = {
        startac = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        kick = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        warn = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        ban = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        publicban = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        key = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        key = "https://discord.com/api/webhooks/1198290099356586065/BDzpwpe_7E902U8Nj4lYX110ghIFW6Akar6gfcvWCWVM1SOEgK9xGYG_D_R31AgvszgE",
        key = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        connect = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW",
        disconnect = "https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW"
    }
}